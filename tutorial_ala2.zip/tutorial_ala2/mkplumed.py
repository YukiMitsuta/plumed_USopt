#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright 2025/08/08 MitsutaYuki 
#
# Distributed under terms of the MIT license.

import os

def main():
    """
    
    """
    plumed_template="""
TORSION LABEL=phi ATOMS=5,7,9,15  #CV0
TORSION LABEL=psi ATOMS=7,9,15,17  #CV1
PRINT STRIDE=10 ARG=phi,psi FILE=COLVAR
RESTRAINTMATRIX ...
LABEL=Rest-MAT
ARG=phi,psi
AT=@at@
KAPPA0=@kappa0@
KAPPA1=@kappa1@
... RESTRAINTMATRIX
"""

    at = get_lastline("./COLVAR_cntr")
    at = ",".join(at)
    kappa = get_lastline("./COLVAR_kappa")
    kappa0 = ",".join(kappa[:2])
    kappa1 = ",".join(kappa[2:])

    plumed_template = plumed_template.replace("@at@",at)
    plumed_template = plumed_template.replace("@kappa0@",kappa0)
    plumed_template = plumed_template.replace("@kappa1@",kappa1)
    with open("./plumed.dat","w") as wf:
        wf.write(plumed_template)
    
def get_lastline(filename):
    if not os.path.exists(filename):
        print("Error: there is not "+filename)
        exit()
    for line in open(filename):
        pass
    line = line.replace("\n","")
    at = line.split(" ")[2:]
    return at

if __name__ == "__main__":
    main()


