#!/bin/bash
#
#copyright by Yuki Mitsuta
#2025/08/08


gmx grompp -f ./npt.mdp -o ./npt.tpr -c ./min.gro -p ./topol.top
gmx mdrun -deffnm npt -plumed ./plumed_npt.dat

python3 ./mkplumed.py

gmx grompp -f ./run.mdp -o ./run.tpr -c ./npt.gro -p ./topol.top
gmx mdrun -deffnm run -plumed ./plumed.dat

